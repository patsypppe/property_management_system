import streamlit as st
import mysql.connector
import pandas as pd
import random
# MySQL connection setup
mydb = mysql.connector.connect(
host="127.0.0.1",
port = 3306,
user="root",
password="Pat@12345",
database="REAL_ESTATE_MANAGEMENT",
ssl_disabled=True
)


mycursor = mydb.cursor()
print('Connection Established')
# Authenticate user against database
def update_property_price(p_id, new_price):
    try:
        args = (p_id, new_price)
        mycursor.callproc("UpdatePropertyPrice", args)
        mydb.commit()
        print("Property price updated successfully!")
    except mysql.connector.Error as err:
        print(f"Error: {err}")

def login(username, password):
    try:
        sql = "SELECT * FROM OWNER WHERE own_name = %s AND own_contact = %s"
        val = (username, password)

        mycursor.execute(sql, val)
        user = mycursor.fetchone()

        return user is not None
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return False
    
def generate_random_10_digit_number():
    # Generate a random number between 1000000000 and 9999999999
    random_number = random.randint(100000000, 999999999)
    return random_number
    
def loginbuyer(username, password):
    try:
        sql = "SELECT * FROM BUYER WHERE buyr_name = %s AND buyr_contact = %s"
        val = (username, password)

        mycursor.execute(sql, val)
        user = mycursor.fetchone()

        return user is not None
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return False

# Placeholder for property registration (CRUD operation)
def register_property(property_data):
    try:
        # SQL query to insert property information into the 'property' table
        sql = "INSERT INTO property (pty_id, price, sqt_foot, pty_address, pty_type, no_of_bedroom, no_of_bathroom, owner_id) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
        
        # Tuple containing property data
        val = (
            property_data["pty_id"],
            property_data["price"],
            property_data["sqt_foot"],
            property_data["address"],
            property_data["pty_type"],
            property_data["no_of_bedroom"],
            property_data["no_of_bathroom"],
            property_data["own_id"]
        )

        # Execute the SQL query
        mycursor.execute(sql, val)

        # Commit the changes to the database
        mydb.commit()

        print("Property Registered Successfully!")
    except mysql.connector.Error as err:
        print(f"Error: {err}")

def generate_random_10_digit_number():
    # Generate a random number between 1000000000 and 9999999999
    random_number = random.randint(100000000, 999999999)
    return random_number
# Register Owner functionality
def register_owner(owner_data):
    try:
        sql = "INSERT INTO owner (own_id, own_name, own_contact, own_add) VALUES (%s, %s, %s, %s)"
        val = (owner_data["own_id"], owner_data["own_name"], owner_data["own_contact"], owner_data["own_add"])

        mycursor.execute(sql, val)
        mydb.commit()
        st.success("Owner Registered Successfully!")
    except mysql.connector.Error as err:
        st.error(f"Error: {err}")

def register_buyer(buyr_data):
    try:
        sql = "INSERT INTO buyer (buyr_id, buyr_name, buyr_contact, buyr_add) VALUES (%s, %s, %s, %s)"
        val = (buyr_data["buyr_id"], buyr_data["buyr_name"], buyr_data["buyr_contact"], buyr_data["buyr_add"])

        mycursor.execute(sql, val)
        mydb.commit()
        st.success("Buyer Registered Successfully!")
    except mysql.connector.Error as err:
        st.error(f"Error: {err}")

# Call the GetPropertiesByType stored procedure
def get_properties_by_type(p_type):
    try:
        args = (p_type,)
        mycursor.callproc("GetPropertiesByType", args)
        for result in mycursor.stored_results():
            properties = result.fetchall()
            
        if not properties:
            st.warning("No properties found.")
        else:
            st.table(properties)
    except mysql.connector.Error as err:
        st.error(f"Error: {err}")

def main():
    st.title("Real Estate Management System")

    # Sidebar Options
    options = ["Login","Register Owner","Login Buyer","Register Buyer", "Register Your Property", "Search Properties","Write SQL Query","Show owners","Write a Review","Show Reviews","Show Properties","Show Registrations","Make a transaction","Register Agent","Show Agents","Update","Delete","Change Your Agent"]
    option = st.sidebar.selectbox("Select an Operation", options)

    if option == "Login":
        # Login Page
        st.subheader("Login")
        login_username = st.text_input("Username")
        login_password = st.text_input("Password", type="password")

        if st.button("Login"):
            if login(login_username, login_password):
                st.success(f"Welcome back, {login_username}!")


                
    if  option=="Register Your Property":

        
        st.subheader("Create a Record")
        pty_id=st.text_input("Enter")
        price=st.text_input("Enter Price")
        sqt_foot=st.text_input("Enter Area")
        address = st.text_input("Enter Address")
        pty_type = st.selectbox("Select Property Type", ["Apartment", "House", "Condo"])
        no_of_bedroom = st.text_input("Enter Number of Bedrooms")
        no_of_bathroom = st.text_input("Enter Number of Bathrooms")
        own_id = st.text_input("Enter Owner ID")
        if st.button("Create"):
            sql= "insert into property(pty_id,price,sqt_foot,pty_address,pty_type,no_of_bedroom,no_of_bathroom,owner_id) values(%s,%s,%s,%s,%s,%s,%s,%s)"
            val= (pty_id,price,sqt_foot,address,pty_type,no_of_bedroom,no_of_bathroom,own_id)
            mycursor.execute(sql,val)
            mydb.commit()
            st.success("Record Created Successfully!!!")

    if option =="Login Buyer":
        st.subheader("Login")
        login_username = st.text_input("Username")
        login_password = st.text_input("Password", type="password")

        if st.button("Login Buyer"):
            if loginbuyer(login_username, login_password):
                st.success(f"Welcome back, {login_username}!")

    if option == "Search Properties":
                # Search Properties Page
        st.subheader("Search Properties")
            

        # Input property type from the user
        pty_type = st.selectbox("Select Property Type", ["", "Apartment", "House", "Condo"])

            # Input price range from the user
        min_price = st.number_input("Minimum Price", min_value=0, step=1)
        max_price = st.number_input("Maximum Price", min_value=0, step=1)

            # Build the SQL query based on user inputs
        sql_query = "SELECT pty_id, price, sqt_foot, pty_address, pty_type, no_of_bedroom, no_of_bathroom FROM PROPERTY WHERE 1"

        if pty_type:
            sql_query += f" AND pty_type = '{pty_type}'"

        if min_price:
            sql_query += f" AND price >= {min_price}"

        if max_price:
            sql_query += f" AND price <= {max_price}"

            # Display properties based on the constructed SQL query
        if st.button("Search"):
            mycursor.execute(sql_query)
            properties = mycursor.fetchall()

                # Display the result
            if properties:
                st.subheader("Properties Matching Search Criteria:")
                column_names = [description[0] for description in mycursor.description]
                df = pd.DataFrame(properties, columns=column_names)
                st.write(df)
            else:
                    st.info("No properties found matching the specified criteria.")

    if option == "Register Owner":
        # Register Owner Page
        st.subheader("Register Owner")
        own_id = st.text_input("Enter Owner ID")
        own_name = st.text_input("Enter Owner Name")
        own_contact = st.text_input("Enter Owner Contact")
        own_add = st.text_input("Enter Owner Address")

        if st.button("Register Owner"):
            owner_data = {
                "own_id": own_id,
                "own_name": own_name,
                "own_contact": own_contact,
                "own_add": own_add
            }
            register_owner(owner_data)

        else:
            st.error("Invalid username or password. Please try again.")

    if option == "Register Buyer":
        # Register Owner Page
        st.subheader("Register Buyer")
        buyr_id = st.text_input("Enter Buyer ID")
        buyr_name = st.text_input("Enter Buyer Name")
        buyr_contact = st.text_input("Enter Buyer Contact")
        buyr_add = st.text_input("Enter Buyer Address")

        if st.button("Register Buyer"):
            buyr_data = {
                "buyr_id": buyr_id,
                "buyr_name": buyr_name,
                "buyr_contact": buyr_contact,
                "buyr_add": buyr_add
            }
            register_buyer(buyr_data)

        else:
            st.error("Invalid username or password. Please try again.")

    if option=="Write SQL Query":
        st.subheader("Write SQL Here")
        sql= st.text_area("Enter Code")
        
        if st.button("Write It"):
            mycursor.execute(sql)
            result = mycursor.fetchall()
            column_names = [description[0] for description in mycursor.description]
            df = pd.DataFrame(result, columns=column_names)
            st.write(df)
    elif option=="Show Agents":
        st.subheader("Agents")
        mycursor.execute("select * from agent")
        result = mycursor.fetchall()
        column_names = [description[0] for description in mycursor.description]
        df = pd.DataFrame(result, columns=column_names)
        st.write(df)

    elif option=="Show Buyers":
        st.subheader("Buyers")
        mycursor.execute("select * from buyer")
        result = mycursor.fetchall()
        column_names = [description[0] for description in mycursor.description]
        df = pd.DataFrame(result, columns=column_names)
        st.write(df)

    elif option=="Show Registrations":
        st.subheader("REGISTRATION")
        mycursor.execute("select * from REGISTRATION")
        result = mycursor.fetchall()
        column_names = [description[0] for description in mycursor.description]
        df = pd.DataFrame(result, columns=column_names)
        st.write(df)
    
    elif option=="Show owners":
        st.subheader("Owners")
        sql = """
SELECT
    property.pty_id,
    property.price,
    property.sqt_foot,
    property.pty_address,
    property.pty_type,
    property.no_of_bedroom,
    property.no_of_bathroom,
    owner.own_name,
    owner.own_contact,
    owner.own_add,
    owner.own_id
FROM
    property
JOIN
    owner ON property.owner_id = owner.own_id;
"""
        mycursor.execute(sql)
        properties_with_owner = mycursor.fetchall()
        column_names = [description[0] for description in mycursor.description]
        df = pd.DataFrame(properties_with_owner, columns=column_names)
        st.write(df)
    elif option == "Make a transaction":
        st.header("Buy A Property")
        tran_id = generate_random_10_digit_number()
        amount = st.text_input("Enter Transaction Amount")
        transaction_type = st.selectbox("Enter Transaction Type",["Cash","Card","Black Money"])
        buyr_id = st.text_input("Enter Buyer ID")
        own_id = st.text_input("Enter Owner ID")

        if st.button("Make Transaction"):
            if tran_id and amount and transaction_type and buyr_id and own_id:
                try:
                    sql = "INSERT INTO TRANSACTION (tran_id, amount, type, buyr_id, own_id) VALUES (%s, %s, %s, %s, %s)"
                    val = (tran_id, amount, transaction_type, buyr_id, own_id)
                    mycursor.execute(sql, val)
                    mydb.commit()
                    st.success("Transaction Successful!")
                except mysql.connector.Error as err:
                    st.error(f"Error: {err}")
            else:
                st.error("Please fill out all the fields before")
    
    elif option=="Write a Review":
        rv_id = generate_random_10_digit_number()
        pty_id = st.text_input("Enter Property ID")
        comments = st.text_area("Enter Your Comments")
        rating = st.slider("Rating (1-5)", 1, 5, 3)

        if st.button("Submit Review"):
            sql = "INSERT INTO review (Review_ID,comments,rating,pty_id) VALUES (%s,%s,%s,%s)"
            val = (rv_id,comments,rating,pty_id)
            mycursor.execute(sql, val)
            mydb.commit()
            st.success("Reviews Submitted Successfully!")

    elif option=="Update Property":
        st.subheader("Update a Record")
        id=st.number_input("Enter Property ID",min_value=1)
        price=st.text_input("Enter New Price")
        
        if st.button("Update"):
            update_property_price(id,price)

    elif option=="Change Your Agent":
        new_agent_id = st.text_input("Enter New Agent ID")
        registration_id=st.text_input("Enter Registration Number")
        sql_query = "UPDATE registration SET agt_id = %s WHERE reg_id = %s"
        values = (new_agent_id, registration_id)

        mycursor.execute(sql_query, values)
        mydb.commit()


    elif option=="Register Agent":
        agt_id=generate_random_10_digit_number()
        agt_name = st.text_input("Enter Agent Name")
        agt_contact = st.text_input("Enter Agent Contact")
        if st.button("Create Agent"):
            sql = "INSERT INTO AGENT (agt_id,agt_name, agt_contact) VALUES (%s, %s, %s)"
            val = (agt_id,agt_name, agt_contact)
            mycursor.execute(sql, val)
            mydb.commit()
            st.success("Agent Registered Successfully!")

    elif option=="Show Reviews":
        mycursor.execute("""
        SELECT r.Review_ID, r.comments, r.rating, p.pty_id, p.price, p.sqt_foot, p.pty_address, p.pty_type, p.no_of_bedroom, p.no_of_bathroom
        FROM review r
        JOIN property p ON r.pty_id = p.pty_id
        """)

    # Fetch all the results
        result = mycursor.fetchall()

    # Display the result using st.table()
        column_names = [description[0] for description in mycursor.description]
        df = pd.DataFrame(result, columns=column_names)
        st.write(df)


if __name__ == "__main__":
    main()